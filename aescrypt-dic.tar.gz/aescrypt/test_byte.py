import os
file_size = os.path.getsize('asino.jpg')
print("filesize : " + str(file_size))
buffer_size = 100
b= bytearray(file_size)
with open("asino.jpg","rb") as f :
  f.readinto(b)
with open("asinocopy.jpg","wb") as fout :
  for i in range(int(file_size/buffer_size)):
    fout.write(b[i*buffer_size:((i+1)*buffer_size) - 1])
  #fout.write(b[int(file_size):(int(file_size+1))+(file_size%buffer_size)]
